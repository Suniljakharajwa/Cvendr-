
import React, { useState } from 'react';
import Web3 from 'web3';
import axios from 'axios';

function App() {
  const [account, setAccount] = useState('');

  const connectWallet = async () => {
    if (window.ethereum) {
      const web3 = new Web3(window.ethereum);
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      setAccount(accounts[0]);
      await axios.post('http://localhost:5000/api/users/register', { wallet: accounts[0] });
    } else {
      alert("Install MetaMask first.");
    }
  };

  return (
    <div>
      <h2>Cvendr Airdrop App</h2>
      <button onClick={connectWallet}>Connect Wallet</button>
      {account && <p>Wallet Connected: {account}</p>}
    </div>
  );
}

export default App;
